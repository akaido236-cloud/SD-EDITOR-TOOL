# SD EDITOR v0.1

Android-only local video editor prototype.

- App name: SD EDITOR
- Package: com.sudandigital.sdeditor
- minSdk: 26
- targetSdk: 35
- Kotlin + Jetpack Compose
- Media3 video preview
- No backend
- No cloud processing
- No paid API

Planned next steps:
1. FFmpeg integration
2. Real trim/export
3. Silence detection
4. Local Whisper captions
5. 9:16 export
