package com.sudandigital.sdeditor

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

private val Background = Color(0xFF0B0B0F)
private val SurfaceCard = Color(0xFF15151B)
private val Accent = Color(0xFF7C5CFF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SDEditorApp() }
    }
}

@Composable
private fun SDEditorApp() {
    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Background,
            surface = SurfaceCard,
            primary = Accent
        )
    ) {
        var videoUri by remember { mutableStateOf<Uri?>(null) }

        val picker = rememberLauncherForActivityResult(
            ActivityResultContracts.GetContent()
        ) { uri -> if (uri != null) videoUri = uri }

        Surface(Modifier.fillMaxSize(), color = Background) {
            val uri = videoUri
            if (uri == null) {
                HomeScreen { picker.launch("video/*") }
            } else {
                EditorScreen(uri) { picker.launch("video/*") }
            }
        }
    }
}

@Composable
private fun HomeScreen(onAddVideo: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(32.dp))
        Text("SD EDITOR", style = MaterialTheme.typography.headlineLarge)
        Text("Local video editor", color = Color.Gray)
        Spacer(Modifier.height(42.dp))

        Card(
            Modifier.fillMaxWidth().height(270.dp),
            colors = CardDefaults.cardColors(containerColor = SurfaceCard)
        ) {
            Column(
                Modifier.fillMaxSize(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(
                    Icons.Default.VideoLibrary, null,
                    Modifier.size(64.dp), tint = Accent
                )
                Spacer(Modifier.height(16.dp))
                Text("Start a new project")
                Spacer(Modifier.height(18.dp))
                Button(onClick = onAddVideo) {
                    Icon(Icons.Default.Add, null)
                    Spacer(Modifier.width(8.dp))
                    Text("Add Video")
                }
            }
        }

        Spacer(Modifier.height(24.dp))
        Text("Your media stays on your device.", color = Color.Gray)
    }
}

@Composable
private fun EditorScreen(uri: Uri, onChangeVideo: () -> Unit) {
    val context = LocalContext.current
    val player = remember(uri) {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(uri))
            prepare()
        }
    }

    DisposableEffect(player) {
        onDispose { player.release() }
    }

    Column(Modifier.fillMaxSize().padding(14.dp)) {
        Row(
            Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "SD EDITOR",
                style = MaterialTheme.typography.titleLarge,
                modifier = Modifier.weight(1f)
            )
            OutlinedButton(onClick = onChangeVideo) { Text("Change") }
        }

        Spacer(Modifier.height(12.dp))

        Card(
            Modifier.fillMaxWidth().height(235.dp),
            shape = RoundedCornerShape(14.dp)
        ) {
            AndroidView(
                factory = { ctx ->
                    PlayerView(ctx).apply {
                        this.player = player
                        useController = true
                    }
                },
                modifier = Modifier.fillMaxSize()
            )
        }

        Spacer(Modifier.height(12.dp))
        Text("Timeline", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(8.dp))

        Box(
            Modifier.fillMaxWidth().height(70.dp)
                .background(SurfaceCard, RoundedCornerShape(12.dp))
                .padding(8.dp)
        ) {
            Row(
                Modifier.fillMaxSize(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("00:00", color = Color.Gray)
                Spacer(Modifier.width(8.dp))
                HorizontalDivider(Modifier.weight(1f))
                Spacer(Modifier.width(8.dp))
                Text("--:--", color = Color.Gray)
            }
        }

        Spacer(Modifier.height(14.dp))

        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            ToolButton(Icons.Default.ContentCut, "Cut")
            ToolButton(Icons.Default.Subtitles, "Captions")
            ToolButton(Icons.Default.GraphicEq, "Audio")
        }

        Spacer(Modifier.height(10.dp))

        Button(
            onClick = { },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Export")
        }
    }
}

@Composable
private fun RowScope.ToolButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String
) {
    OutlinedButton(
        onClick = { },
        modifier = Modifier.weight(1f)
    ) {
        Icon(icon, null, Modifier.size(18.dp))
        Spacer(Modifier.width(5.dp))
        Text(label)
    }
}
